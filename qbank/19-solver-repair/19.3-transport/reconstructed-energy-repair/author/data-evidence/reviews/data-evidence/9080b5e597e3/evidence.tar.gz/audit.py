from pathlib import Path
import sys,json,hashlib,csv,collections,re
import numpy as np,h5py
O=Path(__file__).parent;R=O.resolve().parents[2];T=R/'qbank/19-solver-repair/19.3-transport/reconstructed-energy-repair';W=R/'work/repair-22/su2-2602';sys.path.insert(0,str(O/'snapshot/src'))
from caeoj.sdk import load_problem,load_result
from caeoj.case_grading import grade_case
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def arrays(p):
 with h5py.File(p) as h:return {k:{'dtype':str(h[k].dtype),'shape':list(h[k].shape),'values':h[k][()].tolist()} for k in h}
def vtk(p):
 t=p.read_text().split();i=t.index('POINTS');n=int(t[i+1]);xy=np.array(t[i+3:i+3+3*n],float).reshape(n,3);i=t.index('POINT_DATA')+2;a={}
 while i<len(t):
  kind,name=t[i:i+2]
  if kind=='SCALARS':c=int(t[i+3]);i+=6
  elif kind=='VECTORS':c=3;i+=3
  else:raise ValueError(t[i:i+5])
  a[name]=np.array(t[i:i+n*c],float).reshape(n,c);i+=n*c
 return xy,a
def core(a,v,d):
 n=len(a['edge_ids']);out={k:[] for k in ['temperature','velocity','pressure','density','enthalpy','momentum','energy']};fb=[];offset=[]
 for edge in range(n):
  sides=[]
  delta=np.r_[a['temperature'][0,2*edge+1]-a['temperature'][0,2*edge],a['velocity'][0,2*edge+1]-a['velocity'][0,2*edge],a['pressure'][0,2*edge+1]-a['pressure'][0,2*edge]]
  for side in range(2):
   i=2*edge+side;old=np.r_[a['temperature'][0,i],a['velocity'][0,i],a['pressure'][0,i]];rho=a['density'][0,i,0];H=a['enthalpy'][0,i,0];new=old.copy();cp=v['gamma']*v['gas_constant']/(v['gamma']-1);offset.append(float(H-cp*old[0]-.5*np.dot(old[1:-1],old[1:-1])))
   if v['muscl']:
    grad=np.vstack([a['gradient_temperature'][0,i],a['gradient_velocity'][0,i].reshape(d,d),a['gradient_pressure'][0,i]])
    for k in range(d+2):
     proj=v['relax']*((1-v['kappa'])*np.dot(grad[k],a['displacement'][0,edge])+v['kappa']*delta[k]);factor=1.
     if v['limiter']==1:factor=(delta[k]**2+1e-6+proj*delta[k])/(proj**2+delta[k]**2+1e-6)
     elif v['limiter']==2:factor=a['limiters'][0,i,k]
     new[k]+=(.5 if side==0 else -.5)*factor*proj
    rho=new[-1]/(v['gas_constant']*new[0]);H+=cp*(new[0]-old[0])+.5*(np.dot(new[1:-1],new[1:-1])-np.dot(old[1:-1],old[1:-1]))
   sides.append([new,rho,H])
  reverted=False
  if v['muscl']:
   ratio=np.sqrt(abs(sides[1][1]/sides[0][1]));h=(sides[0][2]+ratio*sides[1][2])/(1+ratio);u=(sides[0][0][1:-1]+ratio*sides[1][0][1:-1])/(1+ratio)
   reverted=any(s[0][-1]<0 or s[1]<0 for s in sides) or h<.5*np.dot(u,u)
  fb.append(bool(reverted))
  for side in range(2):
   i=2*edge+side
   if reverted:sides[side]=[np.r_[a['temperature'][0,i],a['velocity'][0,i],a['pressure'][0,i]],a['density'][0,i,0],a['enthalpy'][0,i,0]]
   z,rho,H=sides[side];vals={'temperature':[z[0]],'velocity':z[1:-1],'pressure':[z[-1]],'density':[rho],'enthalpy':[H],'momentum':rho*z[1:-1],'energy':[rho*H-z[-1]]}
   for k,value in vals.items():out[k].append(value)
 return {k:np.array(value)[None] for k,value in out.items()},fb,offset
def flow_audit(native,p,ref):
 xy,a=vtk(native/'observed.vtk');wx,w=vtk(native/'wall.vtk');order=np.argsort(wx[:,0]);assert np.allclose(xy[:,:2],p.arrays['node_coordinates'],rtol=1e-6,atol=1e-12) and np.allclose(wx[order,:2],p.arrays['wall_coordinates'],rtol=1e-6,atol=1e-12)
 with (native/'history.csv').open() as f:hist=[{k.strip():float(v) for k,v in row.items()} for row in csv.DictReader(f,skipinitialspace=True)]
 last=hist[-1];res=np.array([last[k] for k in ['rms[Rho]','rms[RhoU]','rms[RhoV]','rms[RhoE]','rms[k]','rms[w]']]);raw={'flow_density':a['Density'][None],'flow_momentum':a['Momentum'][None,:,:2],'flow_energy':a['Energy'][None],'wall_cf':w['Skin_Friction_Coefficient'][order,0][None,:,None],'residuals':res[None,None]}
 delta={k:float(abs(raw[k]-ref[k]).max()) for k in raw};assert all(x==0 for x in delta.values());assert res[0]<=-10 and res[3]<=-7
 iterations=p.manifest['physics']['parameters']['iterations']['value'];assert last['Inner_Iter']+1==iterations+100
 assert len(hist)>=101 and all(hist[i+1]['Inner_Iter']-hist[i]['Inner_Iter']==1 for i in range(len(hist)-101,len(hist)-1));cd=np.array([row['CD'] for row in hist[-101:]]);drange=float(np.ptp(cd)/abs(cd[-1]));assert drange<=1e-3
 rho=a['Density'][:,0];P=a['Pressure'][:,0];temp=a['Temperature'][:,0];u=a['Velocity'][:,:2];E=a['Energy'][:,0];tke=a['Turb_Kin_Energy'][:,0];bulk=xy[:,1]>1e-10;eos=abs(rho-P/(287.058*temp))/rho;Eerr=abs(E-(rho*287.058*temp/.4+.5*rho*np.sum(u*u,axis=1)+rho*tke))/abs(E)
 assert np.all(np.isfinite(np.concatenate([z.flatten() for z in a.values()])))
 # Independently estimate external inviscid boundary flux from every actual line edge.
 ls=(native/'mesh.su2').read_text().splitlines();center=(xy[:,:2].min(0)+xy[:,:2].max(0))/2;flux=[];i=0
 while i<len(ls):
  if not ls[i].startswith('MARKER_TAG'):i+=1;continue
  tag=ls[i].split('=')[1].strip();count=int(ls[i+1].split('=')[1]);i+=2;mass=energy=0.
  for line in ls[i:i+count]:
   typ,p0,p1=map(int,line.split()[:3]);assert typ==3;edge=xy[p1,:2]-xy[p0,:2];normal=np.array([edge[1],-edge[0]])
   if np.dot(normal,(xy[p0,:2]+xy[p1,:2])/2-center)<0:normal=-normal
   ids=[p0,p1];un=u[ids]@normal;mass+=float(np.mean(rho[ids]*un));energy+=float(np.mean((E[ids]+P[ids])*un))
  flux.append({'marker':tag,'mass':mass,'inviscid_energy':energy});i+=count
 return {'raw_to_reference_all_fields_maxabs':delta,'last_iteration':last['Inner_Iter'],'history_count':len(hist),'final_residuals':res.tolist(),'last101_CD_relative_range':drange,'nonwall_eos_max_relative':float(eos[bulk].max()),'nonwall_energy_max_relative':float(Eerr[bulk].max()),'wall_eos_max_relative':float(eos[~bulk].max()),'wall_energy_max_relative':float(Eerr[~bulk].max()),'boundary_estimates':flux,'mass_relative_imbalance':sum(z['mass'] for z in flux)/max(abs(z['mass']) for z in flux),'inviscid_energy_relative_imbalance':sum(z['inviscid_energy'] for z in flux)/max(abs(z['inviscid_energy']) for z in flux),'adiabatic_wall_heat_flux_maxabs':float(abs(w['Heat_Flux']).max()),'all_native_arrays':{k:{'shape':list(z.shape),'values':z.tolist()} for k,z in a.items()},'all_native_wall_arrays':{k:{'shape':list(z.shape),'values':z.tolist()} for k,z in w.items()},'files_sha256':{x.name:sha(x) for x in native.iterdir() if x.is_file()}}
rows=[];coverage=collections.Counter()
for scope,paths in [('cases',sorted((T/'cases').glob('*/problem.json'))),('samples',sorted((T/'samples').glob('*/input/problem.json')))]:
 for path in paths:
  p=load_problem(path);a=p.arrays;v={k:x['value'] for k,x in p.manifest['physics']['parameters'].items()};name=path.parent.name if scope=='cases' else path.parent.parent.name;rd=T/'reference'/name if scope=='cases' else path.parent.parent/'reference';r=load_result(p,rd/'reference.h5');assert grade_case(path,rd/'reference.h5',rd/'grading.json')['score']==1
  row={'scope':scope,'case':name,'manifest':p.manifest,'input_arrays':arrays(path.parent/'input.h5'),'reference_arrays':arrays(rd/'reference.h5'),'grading':json.loads((rd/'grading.json').read_text()),'sha256':{str(x.relative_to(T)):sha(x) for x in [path,path.parent/'input.h5',rd/'reference.h5',rd/'grading.json']}}
  if v['operation']==0:
   eos=abs(a['density']-a['pressure']/(v['gas_constant']*a['temperature']));assert np.allclose(a['density'],a['pressure']/(v['gas_constant']*a['temperature']),rtol=1e-12,atol=1e-12);expected,fb,off=core(a,v,p.manifest['spatial_dimension']);err={k:float(abs(r[k]-z).max()) for k,z in expected.items()};assert all(np.allclose(r[k],z,rtol=1e-12,atol=1e-8) for k,z in expected.items());row['independent_core']={'errors':err,'fallback_edges':fb,'stored_stage_offsets':off,'input_eos_maxabs':float(eos.max())}
   coverage['direct']+=1;coverage['direct_edges']+=len(a['edge_ids']);coverage['dimension'+str(p.manifest['spatial_dimension'])]+=1;coverage['limiter'+str(v['limiter'])]+=1;coverage['muscl'+str(v['muscl'])]+=1
  elif scope=='cases':row['native']=flow_audit(W/'formal-replay/reference'/name/'native',p,r);coverage['fullCFD']+=1
  if scope=='cases':
   for mode in ['reference','baseline']:
    out=W/'formal-replay'/mode/name/'result.h5'
    if out.exists():row[mode+'_score']=grade_case(path,out,rd/'grading.json')['score']
  else:
   output=path.parent.parent/'output/result.h5';rr=load_result(p,output);assert all(np.array_equal(rr[k],r[k]) for k in r);row['output_arrays']=arrays(output)
  rows.append(row);print(scope,name,'OK',row.get('independent_core',{}).get('errors',row.get('native',{}).get('raw_to_reference_all_fields_maxabs')),flush=True)
(O/'all-data.json').write_text(json.dumps({'rows':rows,'coverage':dict(coverage)},indent=2,allow_nan=False),encoding='utf-8');print(dict(coverage))
