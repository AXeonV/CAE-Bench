from pathlib import Path
import sys,json,shutil
import numpy as np,h5py
O=Path(__file__).parent;T=O.resolve().parents[2]/'qbank/19-solver-repair/19.3-transport/reconstructed-energy-repair';sys.path.insert(0,str(O/'snapshot-final/src'))
from caeoj.sdk import load_problem
rows=[]
for path in sorted((T/'cases').glob('*/problem.json'))+sorted((T/'samples').glob('*/input/problem.json')):
 p=load_problem(path);rows.append({'kind':'actual-input-valid','path':str(path),'accepted':True});v={k:x['value'] for k,x in p.manifest['physics']['parameters'].items()}
 if v['operation']!=0 or 'samples' in path.parts:continue
 for sign in [-1,1]:
  for label,expected in [('nearest-inside',True),('nearest-outside',False),('onepercent',False)]:
   out=O/'variants-final-eos'/(path.parent.name+'-'+str(sign)+'-'+label);out.mkdir(parents=True,exist_ok=True)
   for f in path.parent.iterdir():
    if f.is_file():shutil.copyfile(f,out/f.name)
   with h5py.File(out/'input.h5','r+') as h:
    a=h['density'][()];target=(h['pressure'][()]/(v['gas_constant']*h['temperature'][()])).flat[0];tol=1e-12+1e-12*abs(target)
    if label=='onepercent':value=target*(1+sign*.01)
    else:
     value=target+sign*tol
     if expected:
      while abs(value-target)>tol:value=np.nextafter(value,target)
     else:
      while abs(value-target)<=tol:value=np.nextafter(value,np.inf if sign>0 else -np.inf)
    a.flat[0]=value;h['density'][...]=a
   try:load_problem(out/'problem.json');accepted=True;error=None
   except Exception as e:accepted=False;error=str(e)
   assert accepted==expected,(path,label,value,target,tol)
   rows.append({'case':path.parent.name,'kind':label,'direction':sign,'expected':expected,'accepted':accepted,'actual_abs_delta':float(abs(value-target)),'input_tolerance':float(tol),'error':error})
 # Large stored-H offset remains legal because EOS applies only to rho.
 out=O/'variants-final-eos'/(path.parent.name+'-H-offset');out.mkdir(parents=True,exist_ok=True)
 for f in path.parent.iterdir():
  if f.is_file():shutil.copyfile(f,out/f.name)
 with h5py.File(out/'input.h5','r+') as h:a=h['enthalpy'][()];a.flat[0]+=12345.;h['enthalpy'][...]=a
 load_problem(out/'problem.json');rows.append({'case':path.parent.name,'kind':'stored-H-offset','accepted':True})
(O/'eos-final.json').write_text(json.dumps(rows,indent=2));print('all',len(rows),'actual-inputs, nearest representable EOS boundaries, 1pct failures and H-offset checks passed')
