from pathlib import Path
import sys,json,subprocess,hashlib,time
import numpy as np
O=Path(__file__).parent.resolve();R=O.parents[2];T=R/'qbank/19-solver-repair/19.3-transport/reconstructed-energy-repair';W=R/'work/repair-22/su2-2602';sys.path.insert(0,str(O/'snapshot/src'))
from caeoj.sdk import load_problem,load_result
image=json.loads((O/'image-independent.json').read_text())['image'];rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for path in sorted((T/'cases').glob('*/problem.json')):
 p=load_problem(path);a=p.arrays;v={k:x['value'] for k,x in p.manifest['physics']['parameters'].items()};d=p.manifest['spatial_dimension']
 if v['operation']!=0:continue
 n=len(a['edge_ids']);tokens=[str(n)]
 for i in range(n):
  tokens.extend(map(str,[d,v['gamma'],v['gas_constant'],v['kappa'],v['relax'],int(v['muscl']),int(v['limiter'])]));tokens.extend(map(str,a['displacement'][0,i]))
  for end in [2*i,2*i+1]:
   for k in ['temperature','velocity','pressure','density','enthalpy']:tokens.extend(map(str,a[k][0,end]))
   grad=np.vstack([a['gradient_temperature'][0,end],a['gradient_velocity'][0,end].reshape(d,d),a['gradient_pressure'][0,end]]);tokens.extend(map(str,grad.flatten()));tokens.extend(map(str,a['limiters'][0,end]))
 payload=' '.join(tokens)+'\n';out=O/'native-direct'/path.parent.name;out.mkdir(parents=True,exist_ok=True);(out/'payload.txt').write_text(payload)
 cmd=['docker','run','--rm','--network','none','--cpus','4','--memory','8g','--user','1000:1000','--entrypoint','/cache/driver-fixed','-i','-v',str(W)+':/cache:ro',image];start=time.monotonic();r=subprocess.run(cmd,input=payload,text=True,capture_output=True);elapsed=time.monotonic()-start;(out/'stdout.json').write_text(r.stdout);(out/'stderr.log').write_text(r.stderr);assert r.returncode==0,r.stderr
 y=np.array(json.loads(r.stdout)).reshape(2*n,2*d+6);raw={'temperature':y[None,:,0:1],'velocity':y[None,:,1:d+1],'pressure':y[None,:,d+1:d+2],'density':y[None,:,d+2:d+3],'enthalpy':y[None,:,d+3:d+4],'momentum':y[None,:,d+5:2*d+5],'energy':y[None,:,2*d+5:2*d+6]};ref=load_result(p,T/'reference'/path.parent.name/'reference.h5');delta={k:float(abs(z-ref[k]).max()) for k,z in raw.items()};assert all(x==0 for x in delta.values());row={'case':path.parent.name,'command':cmd,'elapsed_seconds':elapsed,'exit_code':r.returncode,'max_abs_difference_all_fields':delta,'input_sha256':{'problem.json':sha(path),'input.h5':sha(path.parent/'input.h5')},'raw_sha256':{'payload':sha(out/'payload.txt'),'stdout':sha(out/'stdout.json'),'stderr':sha(out/'stderr.log')},'driver_sha256':sha(W/'driver-fixed'),'image':image};(out/'record.json').write_text(json.dumps(row,indent=2));rows.append(row);print(path.parent.name,'native exact',flush=True)
(O/'native-direct.json').write_text(json.dumps(rows,indent=2))
