from pathlib import Path
import sys,json,shutil
import h5py,numpy as np
O=Path(__file__).parent;T=O.resolve().parents[2]/'qbank/19-solver-repair/19.3-transport/reconstructed-energy-repair';sys.path.insert(0,str(O/'snapshot-final/src'))
from caeoj.sdk import load_problem
base=T/'cases/01-unlimited';flow=T/'cases/08-flatplate-cfl400';rows=[]
def test(name,expected,mut=None,hm=None,source=base):
 d=O/'variants'/name;d.mkdir(parents=True,exist_ok=True)
 for f in source.iterdir():
  if f.is_file():shutil.copyfile(f,d/f.name)
 m=json.loads((d/'problem.json').read_text());
 if mut:mut(m)
 (d/'problem.json').write_text(json.dumps(m))
 if hm:
  with h5py.File(d/'input.h5','r+') as h:hm(h,m)
 try:load_problem(d/'problem.json');accepted=True;error=None
 except Exception as e:accepted=False;error=str(e)
 rows.append(dict(name=name,expected=expected,accepted=accepted,match=accepted==expected,error=error))
def pv(k,v):return lambda m:m['physics']['parameters'][k].update(value=v)
def restore_eos(h,m):h['density'][...]=h['pressure'][()]/(m['physics']['parameters']['gas_constant']['value']*h['temperature'][()])
for k,(lo,hi) in {'gamma':(1.1,1.67),'gas_constant':(200,500),'kappa':(-1,1),'relax':(0,1),'cfl':(100,400),'iterations':(2000,3000)}.items():
 for label,x,good in [('lower',lo,True),('upper',hi,True),('below',lo-1,False),('above',hi+1,False)]:test(k+'-'+label,good,pv(k,x),restore_eos if k=='gas_constant' and good else None)
 test(k+'-unit',False,lambda m,k=k:m['physics']['parameters'][k].update(unit='wrong'))
for k,values in [('operation',[2]),('muscl',[0,1,2]),('limiter',[0,1,2,3])]:
 for x in values:test(k+'-'+str(x),x in ([0,1,2] if k=='limiter' else [0,1]),pv(k,x))
test('iterations-float',False,pv('iterations',2000.));test('iterations-bool',False,pv('iterations',True))
for k in ['temperature','velocity','pressure','density','enthalpy','gradient_temperature','gradient_velocity','gradient_pressure','limiters','displacement','edge_ids','end_ids','times']:
 test(k+'-missing',False,hm=lambda h,m,k=k:h.__delitem__(k))
for k,lo,hi in [('temperature',100,2000),('velocity',-2000,2000),('pressure',1000,1e7),('density',1e-4,100),('enthalpy',1e4,1e7),('limiters',0,1),('displacement',-.2,.2),('gradient_temperature',-1e8,1e8),('gradient_velocity',-1e8,1e8),('gradient_pressure',-1e8,1e8)]:
 for label,x,good in [('lower',lo,True),('upper',hi,True),('below',lo-max(abs(lo),1)*.01,False),('above',hi+max(abs(hi),1)*.01,False)]:
  if k=='density' and good:continue
  def setval(h,m,k=k,x=x,good=good):
   a=h[k][()];a.flat[0]=x;h[k][...]=a
   if good and k=='pressure':
    t=h['temperature'][()];t.flat[0]=500.;h['temperature'][...]=t
   if good and k in ['temperature','pressure']:restore_eos(h,m)
  test(k+'-'+label,good,hm=setval)
def inconsistent(h,m):a=h['density'][()];a.flat[0]*=1.01;h['density'][...]=a
test('density-inconsistent',False,hm=inconsistent)
for ids in ['edge_ids','end_ids','diagnostic_ids','node_ids','wall_ids']:
 def bad(h,m,k=ids):a=h[k][()];a.flat[0]+=1;h[k][...]=a
 test(ids+'-identity',False,hm=bad,source=flow if ids in ['diagnostic_ids','node_ids','wall_ids'] else base)
for k in ['node_coordinates','wall_coordinates']:
 def bad(h,m,k=k):a=h[k][()];a.flat[0]+=.0001;h[k][...]=a
 test(k+'-fixed',False,hm=bad,source=flow)
def repeat(n):
 def f(h,m):
  names=list(h)
  for k in names:
   if k in ['edge_ids','end_ids']:a=np.arange(n if k=='edge_ids' else 2*n,dtype='int64')
   elif k=='times':continue
   else:a=np.tile(h[k][()],(1,n,1))
   del h[k];h[k]=a
 return f
for n in [0,2,32,33]:test('N'+str(n),1<=n<=32,hm=repeat(n))
test('sample-fallback-valid',True,source=T/'cases/06-fallback');test('full3d-invalid',False,mut=lambda m:m.update(spatial_dimension=3),source=flow)
test('output-energy-unit',False,mut=lambda m:m['outputs']['energy'].update(unit='J/kg'))
test('sampling-extrapolate',False,mut=lambda m:m['fields']['velocity']['sampling'].update(extrapolation='constant'))
(O/'variants-final.json').write_text(json.dumps(rows,indent=2));print(len(rows),'mismatches',[(x['name'],x['accepted']) for x in rows if not x['match']])
