[Mesh]
  [gen]
    type = GeneratedMeshGenerator
    nx = 4
    ny = 4
    dim = 2
    elem_type = QUAD9
    xmax = 1
    ymax = 1
  []
  [subdomain]
    type = SubdomainBoundingBoxGenerator
    bottom_left = '0.5 0 0'
    top_right = '1 1 0'
    block_id = 1
    input = gen
  []
  [break_boundary]
    input = subdomain
    type = BreakBoundaryOnSubdomainGenerator
    boundaries = 'bottom top'
  []
  [sideset]
    type = SideSetsBetweenSubdomainsGenerator
    input = break_boundary
    primary_block = '1'
    paired_block = '0'
    new_boundary = 'fluid_left'
  []
  coord_type = RZ
[]

[Variables]
  [T]
    initial_condition = 300
  []
  [velocity]
    order = FIRST
    family = LAGRANGE_VEC
    block = 1
  []
  [pressure]
    block = 1
  []
[]

[ICs]
  [vel]
    type = VectorConstantIC
    variable = velocity
    x_value = 1e-15
    y_value = 1e-15
    block = 1
  []
[]

[Kernels]
  [momentum_time]
    type = INSADMomentumTimeDerivative
    variable = velocity
    block = 1
  []
  [solid_thermal_time]
    type = ADHeatConductionTimeDerivative
    variable = T
    specific_heat = cp
    density_name = rho
    block = 0
  []
  [fluid_thermal_time]
    type = INSADHeatConductionTimeDerivative
    variable = T
    block = 1
  []
  [mass]
    type = INSADMass
    variable = pressure
    block = 1
  []
  [pspg]
    type = INSADMassPSPG
    variable = pressure
    block = 1
  []

  [momentum_convection]
    type = INSADMomentumAdvection
    variable = velocity
    block = 1
  []
  [momentum_viscous]
    type = INSADMomentumViscous
    variable = velocity
    block = 1
  []
  [momentum_pressure]
    type = INSADMomentumPressure
    variable = velocity
    pressure = pressure
    integrate_p_by_parts = true
    block = 1
  []
  [momentum_supg]
    type = INSADMomentumSUPG
    variable = velocity
    velocity = velocity
    block = 1
  []

  [temperature_advection]
    type = INSADEnergyAdvection
    variable = T
     block = 1
  []
  [temperature_supg]
    type = INSADEnergySUPG
    variable = T
    velocity = velocity
    block = 1
  []
  [temperature_conduction]
    type = ADHeatConduction
    variable = T
    thermal_conductivity = 'k'
  []
  [heat_source]
    type = BodyForce
    variable = T
    block = 0
    function = '((0)*(1)+(1)*((x/1))+(1)*((y/1)))*(1+(0)*t)'
  []
[]

[BCs]
  [velocity_inlet]
    type = VectorFunctionDirichletBC
    variable = velocity
    function_y = '4*(1)*((x-0.5)/0.5)*(1-((x-0.5)/0.5))'
    boundary = 'bottom_to_1'
  []
  [wall]
    type = VectorFunctionDirichletBC
    variable = velocity
    boundary = 'fluid_left right'
  []
  [convective_heat_transfer]
    type = ConvectiveHeatFluxBC
    variable = T
    T_infinity = 300
    heat_transfer_coefficient = 1
    boundary = 'right'
  []
[]

[Materials]
  [solid]
    type = ADGenericConstantMaterial
    prop_names = 'cp rho k mu'
    prop_values = '2 3 1 1'
    block = 0
  []
  [fluid]
    type = ADGenericConstantMaterial
    prop_names = 'cp rho k mu'
    prop_values = '4 5 1 1'
    block = 1
  []
  [ins]
    type = INSADStabilized3Eqn
    pressure = pressure
    velocity = velocity
    temperature = T
    block = 1
  []
[]

[Executioner]
  type = Transient
  scheme = implicit-euler
  dt = 0.10000000000000001
  num_steps = 3
  solve_type = NEWTON
  petsc_options_iname = '-pc_type -pc_factor_shift_type'
  petsc_options_value = 'lu       NONZERO'
[]

[Postprocessors]
  [temp_integral_0]
    type = ElementIntegralVariablePostprocessor
    variable = T
    block = 0
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [energy_0]
    type = LinearCombinationPostprocessor
    pp_names = temp_integral_0
    pp_coefs = 6
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [temp_integral_1]
    type = ElementIntegralVariablePostprocessor
    variable = T
    block = 1
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [energy_1]
    type = LinearCombinationPostprocessor
    pp_names = temp_integral_1
    pp_coefs = 20
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [advection]
    type = INSADElementIntegralEnergyAdvection
    temperature = T
    velocity = velocity
    cp = cp
    rho = rho
    block = 1
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [source]
    type = FunctionElementIntegral
    function = '((0)*(1)+(1)*((x/1))+(1)*((y/1)))*(1+(0)*t)'
    block = 0
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [convective_heat_transfer]
    type = ConvectiveHeatTransferSideIntegral
    T_solid = T
    T_fluid = 300
    htc = 1
    boundary = right
    execute_on = 'INITIAL TIMESTEP_END'
  []
[]
[Outputs]
 console = false
 file_base = result
  [csv]
    type = CSV
    precision = 17
    execute_on = 'INITIAL TIMESTEP_END'
  []
[]

[AuxVariables]
  [ux]
    order = FIRST
    block = 1
  []
  [uy]
    order = FIRST
    block = 1
  []
  [uz]
    order = FIRST
    block = 1
  []
[]
[AuxKernels]
  [component_x]
    type = VectorVariableComponentAux
    variable = ux
    vector_variable = velocity
    component = x
    block = 1
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [component_y]
    type = VectorVariableComponentAux
    variable = uy
    vector_variable = velocity
    component = y
    block = 1
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [component_z]
    type = VectorVariableComponentAux
    variable = uz
    vector_variable = velocity
    component = z
    block = 1
    execute_on = 'INITIAL TIMESTEP_END'
  []
[]
[VectorPostprocessors]
  [trace_0]
    type = PointValueSampler
    variable = T
    points = '0.050000000000000003 0.050000000000000003 0 0.125 0.050000000000000003 0 0.20000000000000001 0.050000000000000003 0 0.050000000000000003 0.125 0 0.125 0.125 0 0.20000000000000001 0.125 0 0.050000000000000003 0.20000000000000001 0 0.125 0.20000000000000001 0 0.20000000000000001 0.20000000000000001 0 0.29999999999999999 0.050000000000000003 0 0.375 0.050000000000000003 0 0.45000000000000001 0.050000000000000003 0 0.29999999999999999 0.125 0 0.375 0.125 0 0.45000000000000001 0.125 0 0.29999999999999999 0.20000000000000001 0 0.375 0.20000000000000001 0 0.45000000000000001 0.20000000000000001 0 0.050000000000000003 0.29999999999999999 0 0.125 0.29999999999999999 0 0.20000000000000001 0.29999999999999999 0 0.050000000000000003 0.375 0 0.125 0.375 0 0.20000000000000001 0.375 0 0.050000000000000003 0.45000000000000001 0 0.125 0.45000000000000001 0 0.20000000000000001 0.45000000000000001 0 0.29999999999999999 0.29999999999999999 0 0.375 0.29999999999999999 0 0.45000000000000001 0.29999999999999999 0 0.29999999999999999 0.375 0 0.375 0.375 0 0.45000000000000001 0.375 0 0.29999999999999999 0.45000000000000001 0 0.375 0.45000000000000001 0 0.45000000000000001 0.45000000000000001 0 0.050000000000000003 0.55000000000000004 0 0.125 0.55000000000000004 0 0.20000000000000001 0.55000000000000004 0 0.050000000000000003 0.625 0 0.125 0.625 0 0.20000000000000001 0.625 0 0.050000000000000003 0.69999999999999996 0 0.125 0.69999999999999996 0 0.20000000000000001 0.69999999999999996 0 0.29999999999999999 0.55000000000000004 0 0.375 0.55000000000000004 0 0.45000000000000001 0.55000000000000004 0 0.29999999999999999 0.625 0 0.375 0.625 0 0.45000000000000001 0.625 0 0.29999999999999999 0.69999999999999996 0 0.375 0.69999999999999996 0 0.45000000000000001 0.69999999999999996 0 0.050000000000000003 0.80000000000000004 0 0.125 0.80000000000000004 0 0.20000000000000001 0.80000000000000004 0 0.050000000000000003 0.875 0 0.125 0.875 0 0.20000000000000001 0.875 0 0.050000000000000003 0.94999999999999996 0 0.125 0.94999999999999996 0 0.20000000000000001 0.94999999999999996 0 0.29999999999999999 0.80000000000000004 0 0.375 0.80000000000000004 0 0.45000000000000001 0.80000000000000004 0 0.29999999999999999 0.875 0 0.375 0.875 0 0.45000000000000001 0.875 0 0.29999999999999999 0.94999999999999996 0 0.375 0.94999999999999996 0 0.45000000000000001 0.94999999999999996 0'
    sort_by = id
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [trace_1]
    type = PointValueSampler
    variable = 'T ux uy uz'
    points = '0.55000000000000004 0.050000000000000003 0 0.625 0.050000000000000003 0 0.69999999999999996 0.050000000000000003 0 0.55000000000000004 0.125 0 0.625 0.125 0 0.69999999999999996 0.125 0 0.55000000000000004 0.20000000000000001 0 0.625 0.20000000000000001 0 0.69999999999999996 0.20000000000000001 0 0.80000000000000004 0.050000000000000003 0 0.875 0.050000000000000003 0 0.94999999999999996 0.050000000000000003 0 0.80000000000000004 0.125 0 0.875 0.125 0 0.94999999999999996 0.125 0 0.80000000000000004 0.20000000000000001 0 0.875 0.20000000000000001 0 0.94999999999999996 0.20000000000000001 0 0.55000000000000004 0.29999999999999999 0 0.625 0.29999999999999999 0 0.69999999999999996 0.29999999999999999 0 0.55000000000000004 0.375 0 0.625 0.375 0 0.69999999999999996 0.375 0 0.55000000000000004 0.45000000000000001 0 0.625 0.45000000000000001 0 0.69999999999999996 0.45000000000000001 0 0.80000000000000004 0.29999999999999999 0 0.875 0.29999999999999999 0 0.94999999999999996 0.29999999999999999 0 0.80000000000000004 0.375 0 0.875 0.375 0 0.94999999999999996 0.375 0 0.80000000000000004 0.45000000000000001 0 0.875 0.45000000000000001 0 0.94999999999999996 0.45000000000000001 0 0.55000000000000004 0.55000000000000004 0 0.625 0.55000000000000004 0 0.69999999999999996 0.55000000000000004 0 0.55000000000000004 0.625 0 0.625 0.625 0 0.69999999999999996 0.625 0 0.55000000000000004 0.69999999999999996 0 0.625 0.69999999999999996 0 0.69999999999999996 0.69999999999999996 0 0.80000000000000004 0.55000000000000004 0 0.875 0.55000000000000004 0 0.94999999999999996 0.55000000000000004 0 0.80000000000000004 0.625 0 0.875 0.625 0 0.94999999999999996 0.625 0 0.80000000000000004 0.69999999999999996 0 0.875 0.69999999999999996 0 0.94999999999999996 0.69999999999999996 0 0.55000000000000004 0.80000000000000004 0 0.625 0.80000000000000004 0 0.69999999999999996 0.80000000000000004 0 0.55000000000000004 0.875 0 0.625 0.875 0 0.69999999999999996 0.875 0 0.55000000000000004 0.94999999999999996 0 0.625 0.94999999999999996 0 0.69999999999999996 0.94999999999999996 0 0.80000000000000004 0.80000000000000004 0 0.875 0.80000000000000004 0 0.94999999999999996 0.80000000000000004 0 0.80000000000000004 0.875 0 0.875 0.875 0 0.94999999999999996 0.875 0 0.80000000000000004 0.94999999999999996 0 0.875 0.94999999999999996 0 0.94999999999999996 0.94999999999999996 0'
    sort_by = id
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [trace_wall]
    type = PointValueSampler
    variable = T
    points = '1 0.050000000000000003 0 1 0.125 0 1 0.20000000000000001 0 1 0.29999999999999999 0 1 0.375 0 1 0.45000000000000001 0 1 0.55000000000000004 0 1 0.625 0 1 0.69999999999999996 0 1 0.80000000000000004 0 1 0.875 0 1 0.94999999999999996 0'
    sort_by = id
    execute_on = 'INITIAL TIMESTEP_END'
  []
[]
