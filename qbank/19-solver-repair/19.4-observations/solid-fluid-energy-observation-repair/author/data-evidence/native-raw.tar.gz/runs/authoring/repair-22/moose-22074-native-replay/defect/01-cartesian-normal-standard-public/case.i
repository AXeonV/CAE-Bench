[Mesh]
  [gen]
    type = GeneratedMeshGenerator
    dim = 3
    nx = 4
    ny = 2
    xmax = 1
    ymax = 1
    elem_type = HEX27
    nz = 2
    zmax = 1
  []
  [split]
    type = SubdomainBoundingBoxGenerator
    input = gen
    bottom_left = '0.5 0 0'
    top_right = '1 1 1'
    block_id = 1
  []
[]
[Variables]
  [dummy]
  []
[]
[AuxVariables]
  [T]
    order = SECOND
  []
  [velocity]
    order = SECOND
    family = LAGRANGE_VEC
    block = 1
  []
[]
[ICs]
  [thermal]
    type = FunctionIC
    variable = T
    function = '(300)*(1)+(2)*((x/1))+(3)*((y/1))+(4)*((z/1))+(1)*((x/1)^2)+(-0.5)*((x/1)*(y/1))+(0.75)*((x/1)*(z/1))+(-1)*((y/1)^2)+(0.5)*((y/1)*(z/1))+(0.25)*((z/1)^2)'
  []
  [flow]
    type = VectorFunctionIC
    variable = velocity
    block = 1
    function_x = '(0.20000000000000001)*(1)+(0.10000000000000001)*((x/1))+(0.050000000000000003)*((y/1))+(-0.10000000000000001)*((z/1))'
    function_y = '(-0.29999999999999999)*(1)+(0.050000000000000003)*((x/1))+(0.20000000000000001)*((y/1))+(0.10000000000000001)*((z/1))'
    function_z = '(0.40000000000000002)*(1)+(-0.10000000000000001)*((x/1))+(0.050000000000000003)*((y/1))+(-0.050000000000000003)*((z/1))'
  []
[]
[Kernels]
  [dummy]
    type = Reaction
    variable = dummy
  []
[]
[Materials]
  [solid]
    type = GenericConstantMaterial
    prop_names = 'cp rho'
    prop_values = '3 2'
    block = 0
  []
  [fluid]
    type = GenericConstantMaterial
    prop_names = 'cp rho'
    prop_values = '7 5'
    block = 1
  []
[]
[Executioner]
 type = Steady
 solve_type = NEWTON
[]
[Postprocessors]
  [temp_integral_0]
    type = ElementIntegralVariablePostprocessor
    variable = T
    block = 0
    execute_on = INITIAL
  []
  [energy_0]
    type = LinearCombinationPostprocessor
    pp_names = temp_integral_0
    pp_coefs = 6
    execute_on = INITIAL
  []
  [temp_integral_1]
    type = ElementIntegralVariablePostprocessor
    variable = T
    block = 1
    execute_on = INITIAL
  []
  [energy_1]
    type = LinearCombinationPostprocessor
    pp_names = temp_integral_1
    pp_coefs = 35
    execute_on = INITIAL
  []
  [advection]
    type = INSElementIntegralEnergyAdvection
    temperature = T
    velocity = velocity
    cp = cp
    rho = rho
    block = 1
    execute_on = INITIAL
  []
  [source]
    type = FunctionElementIntegral
    function = '((0)*(1)+(1)*((x/1))+(1)*((y/1)))*(1+(0)*t)'
    block = 0
    execute_on = INITIAL
  []
  [convective_heat_transfer]
    type = Receiver
    default = 0
    execute_on = INITIAL
  []
[]
[Outputs]
 console = false
 file_base = result
  [csv]
    type = CSV
    precision = 17
    execute_on = INITIAL
  []
[]
