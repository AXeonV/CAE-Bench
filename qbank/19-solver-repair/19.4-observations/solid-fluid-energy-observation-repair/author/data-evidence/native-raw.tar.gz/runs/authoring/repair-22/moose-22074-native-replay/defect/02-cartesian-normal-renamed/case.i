[Mesh]
  [gen]
    type = GeneratedMeshGenerator
    dim = 3
    nx = 4
    ny = 2
    xmax = 0.40000000000000002
    ymax = 0.69999999999999996
    elem_type = HEX27
    nz = 2
    zmax = 0.20000000000000001
  []
  [split]
    type = SubdomainBoundingBoxGenerator
    input = gen
    bottom_left = '0.20000000000000001 0 0'
    top_right = '0.40000000000000002 0.69999999999999996 0.20000000000000001'
    block_id = 1
  []
[]
[Variables]
  [dummy]
  []
[]
[AuxVariables]
  [T]
    order = SECOND
  []
  [velocity]
    order = SECOND
    family = LAGRANGE_VEC
    block = 1
  []
[]
[ICs]
  [thermal]
    type = FunctionIC
    variable = T
    function = '(310)*(1)+(-3)*((x/0.40000000000000002))+(2)*((y/0.69999999999999996))+(1)*((z/0.20000000000000001))+(-0.5)*((x/0.40000000000000002)^2)+(0.25)*((x/0.40000000000000002)*(y/0.69999999999999996))+(-0.10000000000000001)*((x/0.40000000000000002)*(z/0.20000000000000001))+(0.20000000000000001)*((y/0.69999999999999996)^2)+(0.29999999999999999)*((y/0.69999999999999996)*(z/0.20000000000000001))+(-0.20000000000000001)*((z/0.20000000000000001)^2)'
  []
  [flow]
    type = VectorFunctionIC
    variable = velocity
    block = 1
    function_x = '(-0.20000000000000001)*(1)+(0.10000000000000001)*((x/0.40000000000000002))+(0.20000000000000001)*((y/0.69999999999999996))+(0.10000000000000001)*((z/0.20000000000000001))'
    function_y = '(0.29999999999999999)*(1)+(-0.10000000000000001)*((x/0.40000000000000002))+(0.10000000000000001)*((y/0.69999999999999996))+(0)*((z/0.20000000000000001))'
    function_z = '(-0.40000000000000002)*(1)+(0.20000000000000001)*((x/0.40000000000000002))+(0)*((y/0.69999999999999996))+(0.10000000000000001)*((z/0.20000000000000001))'
  []
[]
[Kernels]
  [dummy]
    type = Reaction
    variable = dummy
  []
[]
[Materials]
  [solid]
    type = GenericConstantMaterial
    prop_names = 'heat_capacity mass_density'
    prop_values = '460 780'
    block = 0
  []
  [fluid]
    type = GenericConstantMaterial
    prop_names = 'heat_capacity mass_density'
    prop_values = '4180 997'
    block = 1
  []
[]
[Executioner]
 type = Steady
 solve_type = NEWTON
[]
[Postprocessors]
  [temp_integral_0]
    type = ElementIntegralVariablePostprocessor
    variable = T
    block = 0
    execute_on = INITIAL
  []
  [energy_0]
    type = LinearCombinationPostprocessor
    pp_names = temp_integral_0
    pp_coefs = 358800
    execute_on = INITIAL
  []
  [temp_integral_1]
    type = ElementIntegralVariablePostprocessor
    variable = T
    block = 1
    execute_on = INITIAL
  []
  [energy_1]
    type = LinearCombinationPostprocessor
    pp_names = temp_integral_1
    pp_coefs = 4167460
    execute_on = INITIAL
  []
  [advection]
    type = INSElementIntegralEnergyAdvection
    temperature = T
    velocity = velocity
    cp = heat_capacity
    rho = mass_density
    block = 1
    execute_on = INITIAL
  []
  [source]
    type = FunctionElementIntegral
    function = '((0)*(1)+(1)*((x/0.40000000000000002))+(1)*((y/0.69999999999999996)))*(1+(0)*t)'
    block = 0
    execute_on = INITIAL
  []
  [convective_heat_transfer]
    type = Receiver
    default = 0
    execute_on = INITIAL
  []
[]
[Outputs]
 console = false
 file_base = result
  [csv]
    type = CSV
    precision = 17
    execute_on = INITIAL
  []
[]
