[Mesh]
  [gen]
    type = GeneratedMeshGenerator
    dim = 2
    nx = 6
    ny = 4
    xmax = 0.59999999999999998
    ymax = 0.29999999999999999
    elem_type = QUAD9
  []
  [split]
    type = SubdomainBoundingBoxGenerator
    input = gen
    bottom_left = '0.29999999999999999 0 0'
    top_right = '0.59999999999999998 0.29999999999999999 0'
    block_id = 1
  []
 coord_type = RZ
[]
[Variables]
  [dummy]
  []
[]
[AuxVariables]
  [T]
    order = SECOND
  []
  [velocity]
    order = SECOND
    family = LAGRANGE_VEC
    block = 1
  []
[]
[ICs]
  [thermal]
    type = FunctionIC
    variable = T
    function = '(300)*(1)+(0)*((x/0.59999999999999998))+(-4)*((y/0.29999999999999999))+(0)*(0)+(1)*((x/0.59999999999999998)^2)+(-0.5)*((x/0.59999999999999998)*(y/0.29999999999999999))+(0)*((x/0.59999999999999998)*0)+(-1)*((y/0.29999999999999999)^2)+(0)*((y/0.29999999999999999)*0)+(0)*(0^2)'
  []
  [flow]
    type = VectorFunctionIC
    variable = velocity
    block = 1
    function_x = '(0.20000000000000001)*(1)+(0.10000000000000001)*((x/0.59999999999999998))+(0.050000000000000003)*((y/0.29999999999999999))+(0)*(0)'
    function_y = '(-0.29999999999999999)*(1)+(0.050000000000000003)*((x/0.59999999999999998))+(0.20000000000000001)*((y/0.29999999999999999))+(0)*(0)'
    function_z = '(0)*(1)+(0)*((x/0.59999999999999998))+(0)*((y/0.29999999999999999))+(0)*(0)'
  []
[]
[Kernels]
  [dummy]
    type = Reaction
    variable = dummy
  []
[]
[Materials]
  [solid]
    type = ADGenericConstantMaterial
    prop_names = 'heat_capacity mass_density'
    prop_values = '3 2'
    block = 0
  []
  [fluid]
    type = ADGenericConstantMaterial
    prop_names = 'heat_capacity mass_density'
    prop_values = '7 5'
    block = 1
  []
[]
[Executioner]
 type = Steady
 solve_type = NEWTON
[]
[Postprocessors]
  [temp_integral_0]
    type = ElementIntegralVariablePostprocessor
    variable = T
    block = 0
    execute_on = INITIAL
  []
  [energy_0]
    type = LinearCombinationPostprocessor
    pp_names = temp_integral_0
    pp_coefs = 6
    execute_on = INITIAL
  []
  [temp_integral_1]
    type = ElementIntegralVariablePostprocessor
    variable = T
    block = 1
    execute_on = INITIAL
  []
  [energy_1]
    type = LinearCombinationPostprocessor
    pp_names = temp_integral_1
    pp_coefs = 35
    execute_on = INITIAL
  []
  [advection]
    type = INSADElementIntegralEnergyAdvection
    temperature = T
    velocity = velocity
    cp = heat_capacity
    rho = mass_density
    block = 1
    execute_on = INITIAL
  []
  [source]
    type = FunctionElementIntegral
    function = '((0)*(1)+(1)*((x/0.59999999999999998))+(1)*((y/0.29999999999999999)))*(1+(0)*t)'
    block = 0
    execute_on = INITIAL
  []
  [convective_heat_transfer]
    type = Receiver
    default = 0
    execute_on = INITIAL
  []
[]
[Outputs]
 console = false
 file_base = result
  [csv]
    type = CSV
    precision = 17
    execute_on = INITIAL
  []
[]
