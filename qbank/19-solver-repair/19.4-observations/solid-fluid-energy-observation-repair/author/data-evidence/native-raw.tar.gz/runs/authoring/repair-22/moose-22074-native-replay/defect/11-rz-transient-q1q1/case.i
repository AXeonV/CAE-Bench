[Mesh]
  [gen]
    type = GeneratedMeshGenerator
    nx = 4
    ny = 4
    dim = 2
    elem_type = QUAD9
    xmax = 1
    ymax = 1
  []
  [subdomain]
    type = SubdomainBoundingBoxGenerator
    bottom_left = '0.5 0 0'
    top_right = '1 1 0'
    block_id = 1
    input = gen
  []
  [break_boundary]
    input = subdomain
    type = BreakBoundaryOnSubdomainGenerator
    boundaries = 'bottom top'
  []
  [sideset]
    type = SideSetsBetweenSubdomainsGenerator
    input = break_boundary
    primary_block = '1'
    paired_block = '0'
    new_boundary = 'fluid_left'
  []
  coord_type = RZ
[]

[Variables]
  [T]
    initial_condition = 300
  []
  [velocity]
    order = FIRST
    family = LAGRANGE_VEC
    block = 1
  []
  [pressure]
    block = 1
  []
[]

[ICs]
  [vel]
    type = VectorConstantIC
    variable = velocity
    x_value = 1e-15
    y_value = 1e-15
    block = 1
  []
[]

[Kernels]
  [momentum_time]
    type = INSADMomentumTimeDerivative
    variable = velocity
    block = 1
  []
  [solid_thermal_time]
    type = ADHeatConductionTimeDerivative
    variable = T
    specific_heat = cp
    density_name = rho
    block = 0
  []
  [fluid_thermal_time]
    type = INSADHeatConductionTimeDerivative
    variable = T
    block = 1
  []
  [mass]
    type = INSADMass
    variable = pressure
    block = 1
  []
  [pspg]
    type = INSADMassPSPG
    variable = pressure
    block = 1
  []

  [momentum_convection]
    type = INSADMomentumAdvection
    variable = velocity
    block = 1
  []
  [momentum_viscous]
    type = INSADMomentumViscous
    variable = velocity
    block = 1
  []
  [momentum_pressure]
    type = INSADMomentumPressure
    variable = velocity
    pressure = pressure
    integrate_p_by_parts = true
    block = 1
  []
  [momentum_supg]
    type = INSADMomentumSUPG
    variable = velocity
    velocity = velocity
    block = 1
  []

  [temperature_advection]
    type = INSADEnergyAdvection
    variable = T
     block = 1
  []
  [temperature_supg]
    type = INSADEnergySUPG
    variable = T
    velocity = velocity
    block = 1
  []
  [temperature_conduction]
    type = ADHeatConduction
    variable = T
    thermal_conductivity = 'k'
  []
  [heat_source]
    type = BodyForce
    variable = T
    block = 0
    function = '((0)*(1)+(1)*((x/1))+(1)*((y/1)))*(1+(0)*t)'
  []
[]

[BCs]
  [velocity_inlet]
    type = VectorFunctionDirichletBC
    variable = velocity
    function_y = '4*(1)*((x-0.5)/0.5)*(1-((x-0.5)/0.5))'
    boundary = 'bottom_to_1'
  []
  [wall]
    type = VectorFunctionDirichletBC
    variable = velocity
    boundary = 'fluid_left right'
  []
  [convective_heat_transfer]
    type = ConvectiveHeatFluxBC
    variable = T
    T_infinity = 300
    heat_transfer_coefficient = 1
    boundary = 'right'
  []
[]

[Materials]
  [solid]
    type = ADGenericConstantMaterial
    prop_names = 'cp rho k mu'
    prop_values = '2 3 1 1'
    block = 0
  []
  [fluid]
    type = ADGenericConstantMaterial
    prop_names = 'cp rho k mu'
    prop_values = '4 5 1 1'
    block = 1
  []
  [ins]
    type = INSADStabilized3Eqn
    pressure = pressure
    velocity = velocity
    temperature = T
    block = 1
  []
[]

[Executioner]
  type = Transient
  scheme = implicit-euler
  dt = 0.10000000000000001
  num_steps = 3
  solve_type = NEWTON
  petsc_options_iname = '-pc_type -pc_factor_shift_type'
  petsc_options_value = 'lu       NONZERO'
[]

[Postprocessors]
  [temp_integral_0]
    type = ElementIntegralVariablePostprocessor
    variable = T
    block = 0
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [energy_0]
    type = LinearCombinationPostprocessor
    pp_names = temp_integral_0
    pp_coefs = 6
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [temp_integral_1]
    type = ElementIntegralVariablePostprocessor
    variable = T
    block = 1
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [energy_1]
    type = LinearCombinationPostprocessor
    pp_names = temp_integral_1
    pp_coefs = 20
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [advection]
    type = INSADElementIntegralEnergyAdvection
    temperature = T
    velocity = velocity
    cp = cp
    rho = rho
    block = 1
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [source]
    type = FunctionElementIntegral
    function = '((0)*(1)+(1)*((x/1))+(1)*((y/1)))*(1+(0)*t)'
    block = 0
    execute_on = 'INITIAL TIMESTEP_END'
  []
  [convective_heat_transfer]
    type = ConvectiveHeatTransferSideIntegral
    T_solid = T
    T_fluid = 300
    htc = 1
    boundary = right
    execute_on = 'INITIAL TIMESTEP_END'
  []
[]
[Outputs]
 console = false
 file_base = result
  [csv]
    type = CSV
    precision = 17
    execute_on = 'INITIAL TIMESTEP_END'
  []
[]
