[Mesh]
  [gen]
    type = GeneratedMeshGenerator
    dim = 3
    nx = 2
    ny = 2
    elem_type = HEX27
    nz = 2
  []
  [split]
    type = SubdomainBoundingBoxGenerator
    input = gen
    bottom_left = '0.5 0 0'
    top_right = '1 1 1'
    block_id = 1
  []
[]
[Variables]
  [dummy]
  []
[]
[AuxVariables]
  [T]
    order = SECOND
  []
  [velocity]
    order = SECOND
    family = LAGRANGE_VEC
    block = 1
  []
  [ux]
    order = SECOND
    block = 1
  []
  [uy]
    order = SECOND
    block = 1
  []
  [uz]
    order = SECOND
    block = 1
  []
[]
[ICs]
  [temperature]
    type = FunctionIC
    variable = T
    function = '300+2*x+3*y+4*z'
  []
  [flow]
    type = VectorFunctionIC
    variable = velocity
    function_x = '0.2+0.1*x'
    function_y = '-0.3+0.2*y'
    function_z = '0.4-0.05*z'
    block = 1
  []
[]
[AuxKernels]
  [component_x]
    type = VectorVariableComponentAux
    variable = ux
    vector_variable = velocity
    component = x
    block = 1
    execute_on = INITIAL
  []
  [component_y]
    type = VectorVariableComponentAux
    variable = uy
    vector_variable = velocity
    component = y
    block = 1
    execute_on = INITIAL
  []
  [component_z]
    type = VectorVariableComponentAux
    variable = uz
    vector_variable = velocity
    component = z
    block = 1
    execute_on = INITIAL
  []
[]
[Kernels]
  [dummy]
    type = Reaction
    variable = dummy
  []
[]
[Materials]
  [phase0]
    type = ADGenericConstantMaterial
    prop_names = 'rho cp'
    prop_values = '2 3'
    block = 0
  []
  [phase1]
    type = ADGenericConstantMaterial
    prop_names = 'rho cp'
    prop_values = '5 7'
    block = 1
  []
[]
[Postprocessors]
  [advection]
    type = INSADElementIntegralEnergyAdvection
    temperature = T
    velocity = velocity
    rho = rho
    cp = cp
    block = 1
    execute_on = INITIAL
  []
  [T_integral_0]
    type = ElementIntegralVariablePostprocessor
    variable = T
    block = 0
    execute_on = INITIAL
  []
  [energy_0]
    type = LinearCombinationPostprocessor
    pp_names = T_integral_0
    pp_coefs = 6
    execute_on = INITIAL
  []
  [T_integral_1]
    type = ElementIntegralVariablePostprocessor
    variable = T
    block = 1
    execute_on = INITIAL
  []
  [energy_1]
    type = LinearCombinationPostprocessor
    pp_names = T_integral_1
    pp_coefs = 35
    execute_on = INITIAL
  []
[]
[VectorPostprocessors]
  [temperature_nodes]
    type = NodalValueSampler
    variable = T
    sort_by = id
    execute_on = INITIAL
  []
  [flow_nodes]
    type = NodalValueSampler
    variable = 'ux uy uz'
    block = 1
    sort_by = id
    execute_on = INITIAL
  []
[]
[Executioner]
 type = Steady
 solve_type = NEWTON
[]
[Outputs]
 console = false
 file_base = result
  [csv]
    type = CSV
    precision = 17
    execute_on = INITIAL
  []
[]
