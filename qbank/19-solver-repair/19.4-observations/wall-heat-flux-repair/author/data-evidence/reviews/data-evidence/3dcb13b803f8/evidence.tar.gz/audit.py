from pathlib import Path
import json,hashlib,sys,importlib.util,collections,csv,zipfile
import numpy as np,h5py
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent;TASK=ROOT/'qbank/19-solver-repair/19.4-observations/wall-heat-flux-repair';WORK=ROOT/'work/repair-22/su2-2347'
sys.path.insert(0,str(OUT/'snapshot/src'))
from caeoj.sdk import load_problem,load_result
from caeoj.validation import read_mesh
from caeoj.case_grading import grade_case
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def arrays(p):
 with h5py.File(p) as h:return {k:{'dtype':str(h[k].dtype),'shape':list(h[k].shape),'values':h[k][()].tolist()} for k in h}
def dump(n,v):(OUT/n).write_text(json.dumps(v,indent=2,allow_nan=False),encoding='utf-8')
s=importlib.util.spec_from_file_location('public_adapter',TASK/'public/run_case.py');adapter=importlib.util.module_from_spec(s);s.loader.exec_module(adapter)
def physical(v,xy,Tin,inletxy,wallxy,result):
 L=float(xy[:,0].max());H=float(xy[:,1].max());k=v['conductivity'];rho=v['density'];cp=v['heat_capacity'];U=v['velocity'];top=v['top_temperature'];bottom=v['bottom_temperature'] if v['boundary_mode']==0 else top+v['bottom_heat_flux']*H/k
 target=bottom+(top-bottom)*xy[:,1]/H;ty=np.full(len(wallxy),(top-bottom)/H);rates=np.array([k*(top-bottom)*L/H,-k*(top-bottom)*L/H]);openflux=0.;details={}
 if U:
  ix=np.argsort(inletxy[:,1]);ys=inletxy[ix,1];g=Tin[ix]-(bottom+(top-bottom)*ys/H);slopes=np.diff(g)/np.diff(ys);alpha=k/(rho*cp)
  ns=np.arange(1,2049);kn=ns*np.pi/H
  bn=2/H/kn**2*np.sum(slopes[None,:]*(np.sin(kn[:,None]*ys[1:])-np.sin(kn[:,None]*ys[:-1])),axis=1)
  disc=np.sqrt(U*U+4*alpha*alpha*kn*kn);rp=(U+disc)/(2*alpha);rn=-2*alpha*kn*kn/(U+disc);ratio=rn/rp;den=1-ratio*np.exp((rn-rp)*L)
  for start in range(0,len(ns),64):
   sl=slice(start,start+64);kk=kn[sl,None];rr=rn[sl,None];pp=rp[sl,None];rat=ratio[sl,None];dd=den[sl,None]
   X=(np.exp(rr*xy[None,:,0])-rat*np.exp(rr*L+pp*(xy[None,:,0]-L)))/dd
   target+=np.sum(bn[sl,None]*np.sin(kk*xy[None,:,1])*X,axis=0)
   Xw=(np.exp(rr*wallxy[None,:,0])-rat*np.exp(rr*L+pp*(wallxy[None,:,0]-L)))/dd
   ty+=np.sum(bn[sl,None]*kk*np.cos(kk*wallxy[None,:,1])*Xw,axis=0)
  # Exact original piecewise-linear inlet at x=0, including endpoint derivatives.
  target[xy[:,0]==0]=np.interp(xy[xy[:,0]==0,1],ys,Tin[ix])
  left=wallxy[:,0]==0;ty[left & (wallxy[:,1]==0)]=(Tin[ix][1]-Tin[ix][0])/(ys[1]-ys[0]);ty[left & (wallxy[:,1]==H)]=(Tin[ix][-1]-Tin[ix][-2])/(ys[-1]-ys[-2])
  integralX=(np.expm1(rn*L)/rn-ratio*np.exp(rn*L)*(-np.expm1(-rp*L))/rp)/den
  rates+=np.array([np.sum(k*bn*kn*integralX),-np.sum(k*bn*kn*np.cos(ns*np.pi)*integralX)])
  XL=np.exp(rn*L)*(1-ratio)/den;Xp0=rn*(1-np.exp((rn-rp)*L))/den
  openflux=float(np.sum(np.where(ns%2==1,2/kn,0)*bn*(rho*cp*U*(XL-1)+k*Xp0)))
  details={'analytical_method':'2048 exact Fourier sine coefficients of actual piecewise-linear inlet, stable separated roots and zero-gradient outlet; validation only','inlet_sine_fundamental':float(bn[0]),'mode_tail_max_last_64':float(np.max(np.abs(bn[-64:])))}
 q=k*ty*np.where(wallxy[:,1]==0,1,-1);T=result['temperature'][0,:,0];qw=result['wall_heat_flux'][0,:,0];td=T-target;qd=qw-q
 native_rates=np.array([result['bottom_heat_rate'][0,0,0],result['top_heat_rate'][0,0,0]])
 ans={'temperature_max_abs_error':float(max(abs(td))),'temperature_rms_error':float(np.sqrt(np.mean(td*td))),'q_max_abs_error':float(max(abs(qd))),'q_relative_l2_error':float(np.linalg.norm(qd)/np.linalg.norm(q)) if np.linalg.norm(q)>0 else float(np.linalg.norm(qd)),'per_wall_q_relative_l2':{},'velocity_max_error':float(np.max(np.abs(result['velocity']-np.array([[[U,0]]])))),'pressure_max_abs':float(max(abs(result['pressure'].ravel()))),'continuum_wall_rates':rates.tolist(),'native_wall_rates':native_rates.tolist(),'continuum_open_flux':openflux,'continuum_balance':float(sum(rates)+openflux),**details}
 for y,label in [(0,'bottom'),(H,'top')]:
  mask=wallxy[:,1]==y;ans['per_wall_q_relative_l2'][label]=float(np.linalg.norm(qd[mask])/np.linalg.norm(q[mask])) if np.linalg.norm(q[mask])>0 else float(np.linalg.norm(qd[mask]))
 if U:
  ys=np.unique(xy[:,1]);leftT=[];rightT=[];dl=[];dr=[]
  def derivative(x,t):
   a=x[1]-x[0];b=x[2]-x[0];return -(a+b)/(a*b)*t[0]+b/(a*(b-a))*t[1]-a/(b*(b-a))*t[2]
  for y in ys:
   ids=np.flatnonzero(xy[:,1]==y);ids=ids[np.argsort(xy[ids,0])];x=xy[ids,0];vals=T[ids];leftT.append(vals[0]);rightT.append(vals[-1]);dl.append(derivative(x[:3],vals[:3]));dr.append(derivative(x[-1:-4:-1],vals[-1:-4:-1]))
  estimate=float(np.trapezoid(rho*cp*U*(np.array(rightT)-leftT)-k*(np.array(dr)-dl),ys));ans['native_open_flux_second_order_estimate']=estimate;ans['native_energy_imbalance_estimate']=float(estimate+sum(native_rates));ans['native_relative_imbalance_estimate']=float(abs(estimate+sum(native_rates))/sum(abs(native_rates)))
 return ans
reports=[];coverage=collections.Counter()
for scope,paths in [('cases',sorted((TASK/'cases').glob('*/problem.json'))),('samples',sorted((TASK/'samples').glob('*/input/problem.json')))]:
 for path in paths:
  name=path.parent.name if scope=='cases' else path.parent.parent.name;p=load_problem(path);a=p.arrays;v={k:r['value'] for k,r in p.manifest['physics']['parameters'].items()};mesh=read_mesh(path.parent/'mesh.msh',geometry=True);rd=TASK/'reference'/name if scope=='cases' else path.parent.parent/'reference';rp=rd/'reference.h5';r=load_result(p,rp);assert grade_case(path,rp,rd/'grading.json')['score']==1
  xy=np.array([mesh['node_coordinates'][int(t)][:2] for t in a['node_ids']]);wallxy=np.array([mesh['node_coordinates'][int(t)][:2] for t in a['wall_ids']]);inletxy=np.array([mesh['node_coordinates'][int(t)][:2] for t in a['inlet_ids']]);L=xy[:,0].max();H=xy[:,1].max();assert xy[:,0].min()==xy[:,1].min()==0
  assert set(kind for kind,_ in mesh['connectivity'].values())=={1,3};assert mesh['groups'][(2,10)]['elements']==mesh['elements'][2]
  for tag,axis,value in [(1,1,0),(2,1,H),(3,0,0),(4,0,L)]:assert all(mesh['node_coordinates'][n][axis]==value for n in mesh['groups'][(1,tag)]['nodes'])
  assert all(x[2]==0 for x in mesh['node_coordinates'].values());assert np.all(xy>=0) and np.all(xy<=[L,H]);assert np.array_equal(a['wall_ids'],sorted(mesh['groups'][(1,1)]['nodes']|mesh['groups'][(1,2)]['nodes']))
  if v['velocity']:
   ix=np.argsort(inletxy[:,1]);assert a['inlet_temperature'][0,ix[0],0]==v['bottom_temperature'] and a['inlet_temperature'][0,ix[-1],0]==v['top_temperature']
  record={'scope':scope,'case':name,'manifest':p.manifest,'raw_mesh':(path.parent/'mesh.msh').read_text(),'input_arrays':arrays(path.parent/'input.h5'),'reference_arrays':arrays(rp),'grading':json.loads((rd/'grading.json').read_text()),'physics_independent':physical(v,xy,a['inlet_temperature'][0,:,0],inletxy,wallxy,r),'mesh_counts':{'nodes':len(xy),'quads':len(mesh['elements'][2]),'lines':len(mesh['elements'][1]),'L':float(L),'H':float(H)},'assets':{str(x.relative_to(TASK)):sha(x) for x in [path,path.parent/'input.h5',path.parent/'mesh.msh',rp,rd/'grading.json']}}
  if scope=='cases':
   for mode in ['reference','baseline','boundary-only','report-only']:
    op=WORK/'formal-replay'/mode/name/'result.h5'
    if op.exists():
     rr=load_result(p,op);g=grade_case(path,op,rd/'grading.json');record[mode+'_replay']={'score':g['score'],'sha256':sha(op),'field_max_abs_difference':{k:float(np.max(abs(rr[k]-r[k]))) for k in p.manifest['outputs']}}
   native=WORK/'retained-native-v1'/name/'native';flow=np.genfromtxt(native/'restart.csv',delimiter=',',names=True);surface=np.genfromtxt(native/'surface.csv',delimiter=',',names=True);flow=flow[np.argsort(flow['PointID'])];wall={int(row['PointID']):row for row in surface};index={int(t):i for i,t in enumerate(a['node_ids'])};q=np.array([wall[index[int(t)]]['Heat_Flux'] for t in a['wall_ids']])
   with (native/'history.csv').open() as f:hist=list(csv.DictReader(f,skipinitialspace=True));last={k.strip():float(val) for k,val in hist[-1].items()}
   raw={'temperature':flow['Temperature'][None,:,None]*300,'velocity':np.column_stack([flow['Velocity_x'],flow['Velocity_y']])[None],'pressure':flow['Pressure'][None,:,None],'wall_heat_flux':q[None,:,None],'bottom_heat_rate':np.array([[[last['HF(hot)']]]]),'top_heat_rate':np.array([[[last['HF(cold)']]]]),'temperature_residual':np.array([[[last['rms[T]']]]])}
   delta={k:float(np.max(abs(raw[k]-r[k]))) for k in raw};assert all(np.all(abs(raw[k]-r[k])<=(.5 if k=='temperature_residual' else 1e-5+1e-7*abs(r[k]))) for k in raw);assert last['rms[T]']<=-8
   assert (native/'config.cfg').read_text()==adapter.config(v);payload=OUT/'payloads'/name;payload.mkdir(parents=True,exist_ok=True);adapter.write_su2(payload/'mesh.su2',mesh);assert (payload/'mesh.su2').read_text()==(native/'mesh.su2').read_text()
   if v['velocity']>0:
    lines=['NMARK= 1','MARKER_TAG= left',f'NROW= {len(a["inlet_ids"])}','NCOL= 6','# COORD-X COORD-Y TEMPERATURE VELOCITY NORMAL-X NORMAL-Y']
    for tag,temperature in zip(a['inlet_ids'],a['inlet_temperature'][0,:,0]):
     x,y,_=mesh['node_coordinates'][int(tag)];lines.append(f'{x:.17g} {y:.17g} {temperature:.17g} {v["velocity"]:.17g} 1 0')
    assert (native/'inlet.dat').read_text()=='\n'.join(lines)+'\n'
   record['retained_native']={'field_max_abs_difference':delta,'all_fields_within_public_tolerance':True,'native_last_history':last,'files':{x.name:sha(x) for x in native.iterdir() if x.is_file()},'config_matches_actual_input':True,'su2_mesh_payload_matches_original_tags_and_coordinates':True}
   coverage['cases']+=1;coverage['nodes']+=len(xy);coverage['flow' if v['velocity'] else 'static']+=1;coverage['mixed' if v['boundary_mode'] else 'two_temperature']+=1
  else:
   op=path.parent.parent/'output/result.h5';o=load_result(p,op);assert all(np.array_equal(o[k],r[k]) for k in o);record['output_arrays']=arrays(op);record['output_grade']=grade_case(path,op,rd/'grading.json')['score']
  reports.append(record);print(scope,name,'OK physics',record['physics_independent']['temperature_rms_error'],record['physics_independent']['q_relative_l2_error'],flush=True)
dump('all-data.json',{'cases':reports,'coverage':dict(coverage),'native_evidence_note':'Initial formal temp CSV was not retained; current raw data is a separately retained same executable, unchanged public driver exact-input replay; no references overwritten.'})
print('SUMMARY',dict(coverage))
