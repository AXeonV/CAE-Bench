from pathlib import Path
import json,hashlib,tarfile
R=Path(__file__).resolve().parents[3];O=Path(__file__).parent;T=R/'qbank/19-solver-repair/19.4-observations/wall-heat-flux-repair';W=R/'work/repair-22/su2-2347'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def h(b):return hashlib.sha256(b).hexdigest()
manifest=json.loads((T/'author/data-evidence/source-manifest.json').read_text());actual={}
for path,prefix in [(T/'public/su2-source.tar.gz',''),(W/'mel.tar.gz','externals/mel/')]:
 with tarfile.open(path) as z:
  for m in z.getmembers():
   if m.isfile():actual[prefix+m.name.split('/',1)[1]]=h(z.extractfile(m).read())
assert actual==manifest
assembly=json.loads((T/'.data-assembly.json').read_text());selection=json.loads((T/'data-manifest.json').read_text());cache=W/'hf-fixed-empty-v1/datasets--jimzhouzzy2006--CAE-Bench-OJ/snapshots'/assembly['revision'];checked=[]
for path,v in assembly['files'].items():assert sha(T/path)==v['sha256'] and (T/path).stat().st_size==v['size_bytes'];checked.append(path)
for path,text in assembly['descriptors'].items():
 assert (cache/T.relative_to(R)/path).read_text(encoding='utf-8')==text
 desc=json.loads(text)
 for sub,v in desc['files'].items():
  cp=cache/T.relative_to(R)/str(Path(path).parent/sub);assert cp.stat().st_size==v['size_bytes'] and sha(cp)==v['sha256']
for name,v in selection['cases'].items():
 path=v['case']['path'];assert h(assembly['descriptors'][path].encode())==v['case']['sha256']
 desc=json.loads(assembly['descriptors'][path]);mapping={'input/':'cases/'+name+'/','reference/':'reference/'+name+'/'}
 for f,vv in desc['files'].items():
  local=next(a+f[len(b):] for b,a in mapping.items() if f.startswith(b));assert sha(T/local)==vv['sha256']
for sample,case in [('01','01-skew-conduction'),('02','07-skew-flow-coarse')]:
 for f in ['problem.json','input.h5','mesh.msh']:assert sha(T/'samples'/sample/'input'/f)==sha(T/'cases'/case/f)
 for f in ['grading.json','reference.h5']:assert sha(T/'samples'/sample/'reference'/f)==sha(T/'reference'/case/f)
ret=json.loads((T/'author/data-evidence/retained-native-replay.json').read_text())
for c in ret['cases']:
 assert c['passed'] and all(v==0 for v in c['reference_max_abs_errors'].values())
 for f,v in c['native_sha256'].items():assert sha(W/'retained-native-v1'/c['case']/'native'/f)==v
binding=json.loads((T/'author/data-evidence/retained-native-image-binding.json').read_text())
assert binding['public_driver_sha256']==sha(T/'public/run_case.py')
for path,v in binding['replacement_source_sha256'].items():assert sha(T/'author/generated'/Path(path).name)==v
out={'source_count':len(actual),'source_archive_sha256':sha(T/'public/su2-source.tar.gz'),'mel_archive_sha256':sha(W/'mel.tar.gz'),'source_all_match_manifest':True,'assembly_files_count':len(checked),'descriptor_count':len(assembly['descriptors']),'fixed_revision':assembly['revision'],'all_cached_payloads_and_local_files_match':True,'public_mapping':{'01':'01-skew-conduction','02':'07-skew-flow-coarse'},'retained_native_10_raw_files_all_sha_checked':True,'image_binding':binding}
(O/'bindings.json').write_text(json.dumps(out,indent=2));print(out)
