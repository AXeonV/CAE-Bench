from pathlib import Path
exec((Path(__file__).parent/'variants-audit.py').read_text().split("results=[]")[0])
results=[]
def geom(name,change):
 d=O/'variants'/name;d.mkdir(parents=True,exist_ok=True)
 for f in base.iterdir():
  if f.is_file():shutil.copyfile(f,d/f.name)
 ls=(d/'mesh.msh').read_text().splitlines();change(ls);(d/'mesh.msh').write_text('\n'.join(ls)+'\n')
 try:load_problem(d/'problem.json');ok=True;err=None
 except Exception as e:ok=False;err=str(e)
 results.append(dict(name=name,expected=False,accepted=ok,error=err))
def z(ls):
 i=ls.index('$Nodes');n=int(ls[i+1].split()[1]);start=i+3+n
 for j in range(start,start+n):a=ls[j].split();a[2]='0.01';ls[j]=' '.join(a)
def tri(ls):
 i=ls.index('$Elements')+2
 while ls[i]!='$EndElements':
  a=ls[i].split();n=int(a[3])
  if a[2]=='3':
   a[2]='2';ls[i]=' '.join(a)
   for j in range(i+1,i+1+n):ls[j]=' '.join(ls[j].split()[:4])
  i+=n+1
geom('mesh-off-xy-plane',z);geom('mesh-triangles',tri)
(O/'geometry-variants.json').write_text(json.dumps(results,indent=2));print(results)

