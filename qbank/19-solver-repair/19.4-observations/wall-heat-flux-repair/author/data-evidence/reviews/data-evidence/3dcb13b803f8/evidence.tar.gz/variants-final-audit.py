from pathlib import Path
import sys,json,shutil,copy
import h5py,numpy as np
O=Path(__file__).parent;R=O.parents[2];T=R/'qbank/19-solver-repair/19.4-observations/wall-heat-flux-repair';sys.path.insert(0,str(O/'snapshot-final/src'))
from caeoj.sdk import load_problem
base=T/'samples/01-static-oblique/input'
if not base.exists():base=sorted((T/'samples').glob('*/input'))[0]
results=[]
def test(name,expected,mut=None,hmut=None,source=base):
 d=O/'variants'/name;d.mkdir(parents=True,exist_ok=True)
 for f in source.iterdir():
  if f.is_file():shutil.copyfile(f,d/f.name)
 m=json.loads((d/'problem.json').read_text())
 if mut:mut(m)
 (d/'problem.json').write_text(json.dumps(m),encoding='utf-8')
 if hmut:
  with h5py.File(d/'input.h5','r+') as h:hmut(h)
 try:load_problem(d/'problem.json');actual=True;error=None
 except Exception as e:actual=False;error=str(e)
 results.append(dict(name=name,expected=expected,accepted=actual,match=actual==expected,error=error))
def pv(k,v):return lambda m:m['physics']['parameters'][k].update(value=v)
bounds={'density':(.5,3),'heat_capacity':(500,2000),'viscosity':(.001,.1),'conductivity':(1,20),'velocity':(0,.2),'bottom_temperature':(250,450),'top_temperature':(250,450),'bottom_heat_flux':(-2000,2000),'cfl':(.5,20),'iterations':(100,30000)}
for k,(lo,hi) in bounds.items():
 for label,val,good in [('low',lo,True),('high',hi,True),('below',lo-1 if k=='iterations' else lo-max(abs(lo),1)*.01,False),('above',hi+1 if k=='iterations' else hi+max(abs(hi),1)*.01,False)]:test(k+'-'+label,good,pv(k,val))
 test(k+'-unit',False,lambda m,k=k:m['physics']['parameters'][k].update(unit='invalid'))
test('iterations-float',False,pv('iterations',30000.0));test('iterations-fractional',False,pv('iterations',100.5));test('mode2',False,pv('boundary_mode',2));test('static-mixed',True,pv('boundary_mode',1))
def flowmixed(m):pv('velocity',.1)(m);pv('boundary_mode',1)(m)
test('flow-mixed',False,flowmixed)
flow=sorted((T/'cases').glob('05*/problem.json'))[0].parent
def change_inlet(h):a=h['inlet_temperature'][()];a[0,0,0]+=1;h['inlet_temperature'][...]=a
test('flow-inlet-endpoint-discontinuity',False,hmut=change_inlet,source=flow)
test('static-inlet-endpoint-ignored',True,hmut=change_inlet)
for field in ['times','node_ids','wall_ids','inlet_ids','diagnostic_ids','bottom_observation_id','top_observation_id','bottom_edge_ids','top_edge_ids','inlet_temperature']:
 def missing(h,f=field):del h[f]
 test(field+'-missing',False,hmut=missing)
for field in ['node_ids','wall_ids','inlet_ids','bottom_edge_ids','top_edge_ids']:
 def reverse(h,f=field):a=h[f][()];h[f][...]=a[::-1]
 test(field+'-reversed',False,hmut=reverse)
def badtime(h):h['times'][...]=[1.]
test('steady-time-nonzero',False,hmut=badtime)
def badobs(h):h['diagnostic_ids'][...]=[1]
test('diagnostic-id1',False,hmut=badobs)
def nan(h):a=h['inlet_temperature'][()];a.flat[0]=np.nan;h['inlet_temperature'][...]=a
test('inlet-nan',False,hmut=nan)
test('output-unit',False,lambda m:m['outputs']['wall_heat_flux'].update(unit='W'))
test('sampling-extrapolation',False,lambda m:m['fields']['inlet_temperature']['sampling'].update(extrapolation='constant'))
(O/'variants-final.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(len(results),'mismatches',[(x['name'],x['accepted']) for x in results if not x['match']])
