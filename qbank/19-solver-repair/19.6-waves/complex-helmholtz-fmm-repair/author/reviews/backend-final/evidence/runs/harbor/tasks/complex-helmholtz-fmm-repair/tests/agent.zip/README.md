# 源码修复材料

阅读 `qbank/19-solver-repair/19.6-waves/complex-helmholtz-fmm-repair/instruction.md`、同题 DATA.md 和 `docs/CONTRACT.md`。公开样例位于 `qbank/19-solver-repair/19.6-waves/complex-helmholtz-fmm-repair/samples/`，基线源码与可信驱动源码位于本题 `public/`。

安装共享工具：`python -m pip install .`。已预装工具的评测环境可直接使用。
Python 代码最低版本见 pyproject.toml，锁定依赖所需版本由安装器检查；执行 OS／架构以题面为准。
Gmsh 需要系统动态库（Linux 环境预置 libglu1-mesa、libgl1 等）；运行环境应提前准备齐全，普通 pip 安装不负责安装系统库。
h5py、NumPy、Gmsh、jsonschema 是协议依赖；额外求解依赖由程序选择。


本题提交题面指定的源码替换文件，构建与数据驱动由固定环境提供。按题面操作修改源码、完成构建或语法检查，再用以下命令运行和检查样例：

```text
python qbank/19-solver-repair/19.6-waves/complex-helmholtz-fmm-repair/public/run_case.py --input qbank/19-solver-repair/19.6-waves/complex-helmholtz-fmm-repair/samples/01/input/problem.json --output result.h5
python -m caeoj grade --input qbank/19-solver-repair/19.6-waves/complex-helmholtz-fmm-repair/samples/01/input/problem.json --output result.h5 --grading qbank/19-solver-repair/19.6-waves/complex-helmholtz-fmm-repair/samples/01/reference/grading.json
```

MANIFEST.json 记录公开资产的 SHA-256。源码修复、数据与评分的完整要求以三份公开文档为准。
