"""Installed public contract assembly."""
